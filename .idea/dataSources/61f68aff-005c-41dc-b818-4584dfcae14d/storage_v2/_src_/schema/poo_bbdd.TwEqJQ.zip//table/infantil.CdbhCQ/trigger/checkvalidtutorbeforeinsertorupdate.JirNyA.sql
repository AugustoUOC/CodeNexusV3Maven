create definer = root@localhost trigger CheckValidTutorBeforeInsertOrUpdate
    before insert
    on infantil
    for each row
BEGIN
    IF EXISTS (SELECT 1 FROM Infantil WHERE idSocio = NEW.idTutor) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El idTutor seleccionado no puede ser un socio infantil.';
    END IF;
END;

